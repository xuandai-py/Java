/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASMFinal;

import ASM2.*;
import ASM1.*;
import java.io.Serializable;

/**
 *
 * @author XuanDai
 */
public class NhanVien implements Serializable{
    String maNhanVien;
    String hoTen;
    String tuoi;
    String email;
    double luong;
    
    public NhanVien(){
        
    }

    public NhanVien(String maNhanVien, String hoTen, String tuoi, String email, double luong) {
        this.maNhanVien = maNhanVien;
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.email = email;
        this.luong = luong;
    }

  
    
    @Override
    public String toString(){
        return "ma so: " + maNhanVien+ 
               "ho ten: " + hoTen+
               "tuoi: " + tuoi+
               "email: " + email+
               "luong: " +luong;
                       
        
    }
    
}
